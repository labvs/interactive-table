import arcade
import os

class MyGame(arcade.Window):

    def __init__(self, width, height, title):
        super().__init__(width, height, title)

        file_path = os.path.dirname(os.path.abspath(__file__))
        os.chdir(file_path)

        arcade.set_background_color(arcade.color.YELLOW)

        self.coin_list = None
        self.coin1_list = None

    def setup(self):
        
        self.score = 0
        
        # Create your sprites and sprite lists here
        self.coin_list = arcade.SpriteList()
        coin = arcade.Sprite("zdcfB5i.jpg", 0.1)
        coin.center_x = 200
        coin.center_y = 300
        self.coin_list.append(coin)

        self.coin1_list = arcade.SpriteList()
        coin1 = arcade.Sprite("123456789.jpeg", 0.215)
        coin1.center_x = 400
        coin1.center_y = 300
        self.coin1_list.append(coin1)

    def on_draw(self):
        """
        Render the screen.
        """

        arcade.start_render()

        # Draw the coins
        self.coin_list.draw()
        self.coin1_list.draw()

    def on_mouse_press(self, x, y, button, modifiers):
        """
        Called when the user presses a mouse button.
        """
        print(f"You clicked button number: {button}")
        if button == arcade.MOUSE_BUTTON_LEFT:
            self.coin1_list.remove_object(self.coin1_list)


def on_key_press(self, key, coin_list):
    """Вызывается при нажатии пользователем клавиши"""

    if key == arcade.key.UP:
        self.score += 1
    elif key == arcade.key.DOWN:
        self.player_sprite.change_y = -MOVEMENT_SPEED
    elif key == arcade.key.LEFT:
        self.player_sprite.change_x = -MOVEMENT_SPEED
    elif key == arcade.key.RIGHT:
        self.player_sprite.change_x = MOVEMENT_SPEED


def main():
    """ Main method """
    game = MyGame(800, 600, "SCREEN_TITLE")
    game.setup()
    arcade.run()


if __name__ == "__main__":
    main()
