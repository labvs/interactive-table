from tkinter import *

clicks = 0

def click_button1():
    global clicks
    clicks += 1
    btn1.config(text="Нажат {}-ым".format(clicks), state=DISABLED, background="White")
    #label1 = Label(text=root.btn1.text())
    #label1.place(relx=.2, rely=.3)

def click_button2():
    global clicks
    clicks += 1
    btn2.config(text="Нажат {}-ым".format(clicks), state=DISABLED, background="White")

def click_button3():
    global clicks
    clicks += 1
    btn3.config(text="Нажат {}-ым".format(clicks), state=DISABLED, background="White")

def click_button4():
    global clicks
    clicks += 1
    btn4.config(text="Нажат {}-ым".format(clicks), state=DISABLED, background="White")
 
root = Tk()
root.title("Графическая программа на Python")
root.geometry("400x300+300+250")

btn1 = Button(text="Синий",             # текст кнопки
             background="Blue",         # фоновый цвет кнопки
             foreground="Black",        # цвет текста
             activebackground="#222",   # когда нажата меняет цвет
             padx="20",                 # отступ от границ до содержимого по горизонтали (длина кнопки)
             pady="8",                  # отступ от границ до содержимого по вертикали (высота кнопки)
             font="16",                 # высота шрифта
             command=click_button1
             )
btn1.place(relx=.05, rely=.05, height=30, width=130)

btn2 = Button(text="Зелёный",           # текст кнопки
             background="Green",        # фоновый цвет кнопки
             foreground="Black",        # цвет текста
             activebackground="#222",   # когда нажата меняет цвет
             padx="20",                 # отступ от границ до содержимого по горизонтали (длина кнопки)
             pady="8",                  # отступ от границ до содержимого по вертикали (высота кнопки)
             font="16",                 # высота шрифта
             command=click_button2
             )
btn2.place(relx=.05, rely=.15, height=30, width=130)

btn3 = Button(text="Красный",           # текст кнопки
             background="Red",          # фоновый цвет кнопки
             foreground="Black",        # цвет текста
             activebackground="#222",   # когда нажата меняет цвет
             padx="20",                 # отступ от границ до содержимого по горизонтали (длина кнопки)
             pady="8",                  # отступ от границ до содержимого по вертикали (высота кнопки)
             font="16",                 # высота шрифта
             command=click_button3
             )
btn3.place(relx=.37, rely=.05, height=30, width=130)

btn4 = Button(text="Жёлтый",            # текст кнопки
             background="Yellow",       # фоновый цвет кнопки
             foreground="Black",        # цвет текста
             activebackground="#222",   # когда нажата меняет цвет
             padx="20",                 # отступ от границ до содержимого по горизонтали (длина кнопки)
             pady="8",                  # отступ от границ до содержимого по вертикали (высота кнопки)
             font="16",                 # высота шрифта
             command=click_button4
             )
btn4.place(relx=.37, rely=.15, height=30, width=130)

root.mainloop()

