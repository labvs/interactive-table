import arcade


class MyGame(arcade.application.Window):

    arcade.set_background_color(arcade.color.RED)

    
    def on_draw(self):
        arcade.start_render()
        x = 400; y = 300;
        my_text = arcade.create_text("HELLOW WORLD!!!", arcade.color.WHITE, 50)
        arcade.render_text(my_text, x, y)
        arcade.finish_render()


def main():

    game = MyGame(title="Что-то страшное",fullscreen=True)
    arcade.set_background_color(arcade.color.AMAZON)
    arcade.run()


if __name__ == "__main__":
    main() 

#window.close()
